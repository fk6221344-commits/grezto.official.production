import{W as n}from"./index-CnRF7jmi.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
