import{W as n}from"./index-DcTfGwGh.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
