const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Be2Tf_3B.js","assets/index-DcTfGwGh.js","assets/index-B7G4UbRy.css"])))=>i.map(i=>d[i]);
import{at as o,K as i}from"./index-DcTfGwGh.js";const a=o("Dialog",{web:()=>i(()=>import("./web-Be2Tf_3B.js"),__vite__mapDeps([0,1,2])).then(e=>new e.DialogWeb)});export{a as D};
