const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-C1IBuNUT.js","assets/index-DcTfGwGh.js","assets/index-B7G4UbRy.css"])))=>i.map(i=>d[i]);
import{at as r,K as t}from"./index-DcTfGwGh.js";const o=r("Share",{web:()=>t(()=>import("./web-C1IBuNUT.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
