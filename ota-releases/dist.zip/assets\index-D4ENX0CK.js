const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-B1otzj4f.js","assets/index-CnRF7jmi.js","assets/index-D0fwHzq2.css"])))=>i.map(i=>d[i]);
import{as as o,J as i}from"./index-CnRF7jmi.js";const r=o("Dialog",{web:()=>i(()=>import("./web-B1otzj4f.js"),__vite__mapDeps([0,1,2])).then(e=>new e.DialogWeb)});export{r as D};
