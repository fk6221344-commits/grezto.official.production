const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-tImhtf0o.js","assets/index-CnRF7jmi.js","assets/index-D0fwHzq2.css"])))=>i.map(i=>d[i]);
import{as as r,J as t}from"./index-CnRF7jmi.js";const o=r("Share",{web:()=>t(()=>import("./web-tImhtf0o.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
