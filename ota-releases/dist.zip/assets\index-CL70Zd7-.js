const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-8pcSzO_Q.js","assets/index-D6OtgbPv.js","assets/index-D0fwHzq2.css"])))=>i.map(i=>d[i]);
import{at as o,K as i}from"./index-D6OtgbPv.js";const a=o("Dialog",{web:()=>i(()=>import("./web-8pcSzO_Q.js"),__vite__mapDeps([0,1,2])).then(e=>new e.DialogWeb)});export{a as D};
