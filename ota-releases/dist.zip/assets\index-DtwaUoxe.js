const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-JMmwflCV.js","assets/index-D6OtgbPv.js","assets/index-D0fwHzq2.css"])))=>i.map(i=>d[i]);
import{at as r,K as t}from"./index-D6OtgbPv.js";const o=r("Share",{web:()=>t(()=>import("./web-JMmwflCV.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
