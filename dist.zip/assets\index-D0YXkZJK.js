const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-_vWb2IFV.js","assets/index-Ca3Dqi4H.js","assets/index-B7G4UbRy.css"])))=>i.map(i=>d[i]);
import{at as o,K as i}from"./index-Ca3Dqi4H.js";const a=o("Dialog",{web:()=>i(()=>import("./web-_vWb2IFV.js"),__vite__mapDeps([0,1,2])).then(e=>new e.DialogWeb)});export{a as D};
