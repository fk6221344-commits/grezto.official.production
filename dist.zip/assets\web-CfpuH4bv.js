import{W as n}from"./index-Ca3Dqi4H.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
