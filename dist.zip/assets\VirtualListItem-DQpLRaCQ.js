import{a5 as i,as as a,ak as o}from"./index-Ca3Dqi4H.js";/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const p=[["path",{d:"M13.997 4a2 2 0 0 1 1.76 1.05l.486.9A2 2 0 0 0 18.003 7H20a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2h1.997a2 2 0 0 0 1.759-1.048l.489-.904A2 2 0 0 1 10.004 4z",key:"18u6gg"}],["circle",{cx:"12",cy:"13",r:"3",key:"1vg3eu"}]],x=i("camera",p);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const v=[["path",{d:"M12 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7",key:"1m0v6g"}],["path",{d:"M18.375 2.625a1 1 0 0 1 3 3l-9.013 9.014a2 2 0 0 1-.853.505l-2.873.84a.5.5 0 0 1-.62-.62l.84-2.873a2 2 0 0 1 .506-.852z",key:"ohrbg2"}]],b=i("square-pen",v);function h({children:c,height:t=76,id:l}){const[r,u]=a.useState(!1),n=a.useRef(null);return a.useEffect(()=>{const s=new IntersectionObserver(([d])=>{u(d.isIntersecting)},{rootMargin:"250px 0px",threshold:0}),e=n.current;return e&&s.observe(e),()=>{e&&s.unobserve(e),s.disconnect()}},[]),o.jsx("div",{ref:n,id:l,style:{minHeight:r?void 0:`${t}px`},className:"transition-all duration-150 ease-in-out",children:r?c:o.jsx("div",{style:{height:`${t}px`},className:"w-full bg-transparent border border-transparent"})})}export{x as C,b as S,h as V};
