const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-j1O12Uc-.js","assets/index-Ca3Dqi4H.js","assets/index-B7G4UbRy.css"])))=>i.map(i=>d[i]);
import{at as r,K as t}from"./index-Ca3Dqi4H.js";const o=r("Share",{web:()=>t(()=>import("./web-j1O12Uc-.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
